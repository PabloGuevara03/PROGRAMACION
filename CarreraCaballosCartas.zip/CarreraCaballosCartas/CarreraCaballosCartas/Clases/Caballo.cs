﻿// En Clases/Caballo.cs
using System.Windows.Forms; // Para PictureBox y Label

namespace CarreraCaballosCartas.Clases
{
    public class Caballo
    {
        public string Nombre { get; private set; }
        public PaloEspañol PaloAsociado { get; private set; }
        public int Puntos { get; private set; }
        public PictureBox RepresentacionVisual { get; set; } // Para mostrar el caballo en la pista
        public Label EtiquetaPuntos { get; set; } // Para mostrar los puntos del caballo

        public Caballo(string nombre, PaloEspañol paloAsociado, PictureBox pbVisual, Label lblPuntos)
        {
            Nombre = nombre;
            PaloAsociado = paloAsociado;
            Puntos = 0;
            RepresentacionVisual = pbVisual; // Se asignará desde el Form
            EtiquetaPuntos = lblPuntos;     // Se asignará desde el Form
            ActualizarPuntosVisual();
        }

        public void Avanzar()
        {
            Puntos++;
            ActualizarPuntosVisual();
        }

        public void Reiniciar()
        {
            Puntos = 0;
            ActualizarPuntosVisual();
        }

        private void ActualizarPuntosVisual()
        {
            if (EtiquetaPuntos != null)
            {
                EtiquetaPuntos.Text = Puntos.ToString();
            }
            // Podrías mover el PictureBox del caballo aquí si la pista fuera más compleja
        }
    }
}