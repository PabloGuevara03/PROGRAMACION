﻿// En Clases/Mazo.cs
using System;
using System.Collections.Generic;
using System.Linq;

namespace CarreraCaballosCartas.Clases
{
    public class Mazo
    {
        private List<Carta> _cartas;
        private Random _aleatorio;

        public int CartasRestantes => _cartas.Count;

        public Mazo()
        {
            _aleatorio = new Random();
            InicializarMazo();
            Barajar();
        }

        public void InicializarMazo()
        {
            _cartas = new List<Carta>();
            foreach (PaloEspañol palo in Enum.GetValues(typeof(PaloEspañol)))
            {
                for (int i = 1; i <= 12; i++)
                {
                    if (i >= 8 && i <= 9) continue; // En la baraja española no hay 8s ni 9s
                    _cartas.Add(new Carta(i, palo));
                }
            }
        }

        public void Barajar()
        {
            _cartas = _cartas.OrderBy(c => _aleatorio.Next()).ToList();
        }

        public Carta SacarCarta()
        {
            if (_cartas.Count == 0)
            {
                // Opción: Lanzar excepción, o re-barajar descartes, o simplemente devolver null.
                // Para este juego, si se acaban las cartas, se podría considerar re-barajar.
                // Por simplicidad, si se acaban, creamos y barajamos uno nuevo.
                Console.WriteLine("Se acabó el mazo, creando y barajando uno nuevo.");
                InicializarMazo();
                Barajar();
            }

            Carta cartaSacada = _cartas[0];
            _cartas.RemoveAt(0);
            return cartaSacada;
        }
    }
}