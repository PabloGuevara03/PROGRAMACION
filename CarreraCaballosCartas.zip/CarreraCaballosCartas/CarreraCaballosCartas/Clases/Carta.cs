﻿// En Clases/Carta.cs
namespace CarreraCaballosCartas.Clases
{
    public enum PaloEspañol
    {
        Oro,
        Copa,
        Espada,
        Basto
    }

    public class Carta
    {
        public int Numero { get; set; } // 1-7, 10 (Sota), 11 (Caballo), 12 (Rey)
        public PaloEspañol Palo { get; set; }
        public string NombreArchivoImagen { get; set; }

        public Carta(int numero, PaloEspañol palo)
        {
            Numero = numero;
            Palo = palo;
            // ej: espadas_1.jpg, oros_10.jpg
            NombreArchivoImagen = $"{palo.ToString().ToLower()}_{numero}.jpg";
        }

        public override string ToString()
        {
            string nombreNumero;
            switch (Numero)
            {
                case 10: nombreNumero = "Sota"; break;
                case 11: nombreNumero = "Caballo"; break;
                case 12: nombreNumero = "Rey"; break;
                default: nombreNumero = Numero.ToString(); break;
            }
            return $"{nombreNumero} de {Palo}";
        }
    }
}
