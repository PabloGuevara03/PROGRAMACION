﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarreraCaballosCartas
{

    public partial class EasterEgg : Form
    {
        
        private SoundPlayer _reproductorMusica;

        public EasterEgg()
        {
            InitializeComponent();
            InicializarMusica();
        }
        private void InicializarMusica()
        {
            try
            {

                string rutaMusica1 = Path.Combine(Directory.GetCurrentDirectory(), "KISS.wav");
                if (File.Exists(rutaMusica1))
                {
                    _reproductorMusica = new SoundPlayer(rutaMusica1);
                    _reproductorMusica.Play(); // Reproducir
                }
                else
                {
                    Console.WriteLine("Archivo de música no encontrado.");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error al inicializar música: {ex.Message}");
            }
        }

        private void btnCerrar_Click(object sender, EventArgs e)
        {
            _reproductorMusica?.Stop();
            FormMenuPrincipal formMenuPrincipal = new FormMenuPrincipal();
            this.Close();
            formMenuPrincipal.Show();
        }
    }

}
