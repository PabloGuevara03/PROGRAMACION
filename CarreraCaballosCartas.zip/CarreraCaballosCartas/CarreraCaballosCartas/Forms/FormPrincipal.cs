﻿// En FormPrincipal.cs
using CarreraCaballosCartas.Clases; // Importante
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO; // Para Path.Combine y Directory.GetCurrentDirectory
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CarreraCaballosCartas
{
    public partial class FormPrincipal : Form
    {
        private SoundPlayer _reproductorMusica;
        private Mazo _mazoPrincipal;
        private List<Caballo> _caballosCompetidores;
        private int _metaPuntos;
        private int _rondaActual;
        private decimal _presupuestoJugador;
        private Caballo _caballoApostadoPorJugador;
        private decimal _montoApostadoJugador;

        // Directorio de las imágenes de las cartas
        private string _directorioCartas = Path.Combine(Directory.GetCurrentDirectory(), "Cartas");

        public FormPrincipal()
        {
            InitializeComponent();
            InicializarComponentesJuego();
            ConfigurarEstadoInicial();
            InicializarMusica();
        }

        private void InicializarComponentesJuego()
        {
            _mazoPrincipal = new Mazo();
            _caballosCompetidores = new List<Caballo>();

            // Asegúrate que los nombres de PictureBox y Label coincidan con los que pusiste en el diseñador
            _caballosCompetidores.Add(new Caballo("Caballo de Oros", PaloEspañol.Oro, pbCaballoOros, lblPuntosOrosValor));
            _caballosCompetidores.Add(new Caballo("Caballo de Copas", PaloEspañol.Copa, pbCaballoCopas, lblPuntosCopasValor));
            _caballosCompetidores.Add(new Caballo("Caballo de Espadas", PaloEspañol.Espada, pbCaballoEspadas, lblPuntosEspadasValor));
            _caballosCompetidores.Add(new Caballo("Caballo de Bastos", PaloEspañol.Basto, pbCaballoBastos, lblPuntosBastosValor));

            cmbCaballoApuesta.DataSource = _caballosCompetidores;
            cmbCaballoApuesta.DisplayMember = "Nombre";
            cmbCaballoApuesta.ValueMember = "PaloAsociado"; // O el objeto Caballo entero

            _presupuestoJugador = 1000; // Presupuesto inicial
            ActualizarPresupuestoVisual();
        }

        private void ConfigurarEstadoInicial()
        {
            // Controles de configuración habilitados
            gbConfiguracion.Enabled = true; // Asumiendo que los controles de configuración están en un GroupBox llamado gbConfiguracion
            // O individualmente:
            // rbRapida.Enabled = true;
            // rbEstandar.Enabled = true;
            // rbExtensa.Enabled = true;
            // cmbCaballoApuesta.Enabled = true;
            // nudMontoApuesta.Enabled = true;
            // btnIniciarPartida.Enabled = true;


            // Controles de juego deshabilitados
            btnSacarCarta.Enabled = false;
            pbCartaActual.Image = null;
            lblRondaValor.Text = "0";
            lblResultadoPartida.Text = "";
            lblResultadoPartida.Visible = false;

            foreach (var caballo in _caballosCompetidores)
            {
                caballo.Reiniciar();
            }
            LimpiarPistasVisuales();

            _rondaActual = 0;
        }

        private void LimpiarPistasVisuales()
        {
            flpOrosPista.Controls.Clear();
            flpCopasPista.Controls.Clear();
            flpEspadasPista.Controls.Clear();
            flpBastosPista.Controls.Clear();
        }


        private void ActualizarPresupuestoVisual()
        {
            lblPresupuestoValor.Text = _presupuestoJugador.ToString("C"); // Formato de moneda
            nudMontoApuesta.Maximum = _presupuestoJugador;
        }

        private void btnIniciarPartida_Click(object sender, EventArgs e)
        {
            // 1. Validar selección de modo y apuesta
            if (nudMontoApuesta.Value <= 0 || nudMontoApuesta.Value > _presupuestoJugador)
            {
                MessageBox.Show("El monto de la apuesta no es válido.", "Error de Apuesta", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            if (cmbCaballoApuesta.SelectedItem == null)
            {
                MessageBox.Show("Debes seleccionar un caballo para apostar.", "Error de Apuesta", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // 2. Determinar meta de puntos
            if (rbRapida.Checked) _metaPuntos = 5;
            else if (rbEstandar.Checked) _metaPuntos = 8;
            else if (rbExtensa.Checked) _metaPuntos = 10;
            else
            {
                MessageBox.Show("Por favor, selecciona un modo de juego.", "Modo de Juego", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // 3. Configurar apuesta
            _caballoApostadoPorJugador = (Caballo)cmbCaballoApuesta.SelectedItem;
            _montoApostadoJugador = nudMontoApuesta.Value;
            _presupuestoJugador -= _montoApostadoJugador;
            ActualizarPresupuestoVisual();

            // 4. Preparar el juego
            _mazoPrincipal.InicializarMazo(); // Siempre un mazo fresco al inicio
            _mazoPrincipal.Barajar();

            foreach (var caballo in _caballosCompetidores)
            {
                caballo.Reiniciar();
            }
            LimpiarPistasVisuales();
            _rondaActual = 0;
            lblRondaValor.Text = _rondaActual.ToString();
            lblResultadoPartida.Visible = false;


            // 5. Cambiar estado de controles
            // gbConfiguracion.Enabled = false; // Deshabilitar todo el grupo de configuración
            // O individualmente:
            rbRapida.Enabled = false;
            rbEstandar.Enabled = false;
            rbExtensa.Enabled = false;
            cmbCaballoApuesta.Enabled = false;
            nudMontoApuesta.Enabled = false;
            btnIniciarPartida.Enabled = false;

            btnSacarCarta.Enabled = true;
            pbCartaActual.Image = null; // Limpiar carta anterior si la hubo

            MessageBox.Show($"Partida iniciada. Meta: {_metaPuntos} puntos. Has apostado {_montoApostadoJugador:C} por {_caballoApostadoPorJugador.Nombre}.", "Partida Iniciada", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnSacarCarta_Click(object sender, EventArgs e)
        {
            if (_mazoPrincipal.CartasRestantes == 0)
            {
                MessageBox.Show("¡Se acabaron las cartas del mazo! La partida termina en empate (o puedes implementar re-barajar).", "Fin del Mazo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                ConfigurarEstadoInicial(); // O manejar de otra forma
                return;
            }

            _rondaActual++;
            lblRondaValor.Text = _rondaActual.ToString();

            Carta cartaSacada = _mazoPrincipal.SacarCarta();
            MostrarCarta(cartaSacada);

            Caballo caballoQueAvanza = _caballosCompetidores.FirstOrDefault(c => c.PaloAsociado == cartaSacada.Palo);

            if (caballoQueAvanza != null)
            {
                caballoQueAvanza.Avanzar();
                AgregarMarcadorVisual(caballoQueAvanza); // Añade un marcador a su FlowLayoutPanel

                // Verificar si hay un ganador
                if (caballoQueAvanza.Puntos >= _metaPuntos)
                {
                    ProcesarFinDePartida(caballoQueAvanza);
                }
            }
            else
            {
                // Esto no debería pasar si todos los palos tienen un caballo asociado.
                MessageBox.Show($"Error: No se encontró caballo para el palo {cartaSacada.Palo}", "Error Interno", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void MostrarCarta(Carta carta)
        {
            try
            {
                string rutaImagen = Path.Combine(_directorioCartas, carta.NombreArchivoImagen);
                System.Diagnostics.Debug.WriteLine("Intentando cargar imagen desde: " + rutaImagen);
                if (File.Exists(rutaImagen))
                {
                    pbCartaActual.Image = Image.FromFile(rutaImagen);
                }
                else
                {
                    pbCartaActual.Image = null; // O una imagen por defecto de "carta no encontrada"
                    Console.WriteLine($"Advertencia: No se encontró la imagen {rutaImagen}");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error al cargar imagen de carta: {ex.Message}");
                pbCartaActual.Image = null;
            }
        }

        private void AgregarMarcadorVisual(Caballo caballo)
        {
            FlowLayoutPanel pista = null;
            switch (caballo.PaloAsociado)
            {
                case PaloEspañol.Oro: pista = flpOrosPista; break;
                case PaloEspañol.Copa: pista = flpCopasPista; break;
                case PaloEspañol.Espada: pista = flpEspadasPista; break;
                case PaloEspañol.Basto: pista = flpBastosPista; break;
            }

            if (pista != null)
            {
                PictureBox marcador = new PictureBox
                {
                    Width = 20, // Ancho del marcador
                    Height = pista.ClientSize.Height - 5, // Alto del marcador, ajustado al FlowLayoutPanel
                    Margin = new Padding(1),
                    // Podrías usar un color o una pequeña imagen para el marcador
                    BackColor = Color.FromName(caballo.PaloAsociado.ToString()) // Colores básicos para palos (Gold, LightCoral, LightSlateGray, ForestGreen)
                };
                // Para colores más específicos:
                switch (caballo.PaloAsociado)
                {
                    case PaloEspañol.Oro: marcador.BackColor = Color.Gold; break;
                    case PaloEspañol.Copa: marcador.BackColor = Color.LightCoral; break; // O Red
                    case PaloEspañol.Espada: marcador.BackColor = Color.LightSteelBlue; break; // O Blue
                    case PaloEspañol.Basto: marcador.BackColor = Color.ForestGreen; break; // O Green
                }
                pista.Controls.Add(marcador);
            }
        }


        private void ProcesarFinDePartida(Caballo caballoGanador)
        {
            btnSacarCarta.Enabled = false; // Deshabilitar botón de sacar carta
            string mensajeResultado = $"¡{caballoGanador.Nombre} ha ganado la carrera en la ronda {_rondaActual}!";

            if (caballoGanador == _caballoApostadoPorJugador)
            {
                // Paga 2:1 (devuelve apuesta + ganancia igual a la apuesta)
                // Podrías hacerlo configurable, ej: paga 3 veces lo apostado.
                decimal ganancia = _montoApostadoJugador * 2;
                mensajeResultado += $"\n¡Felicidades! Ganaste tu apuesta de {_montoApostadoJugador:C}. Recibes {ganancia:C}.";
                _presupuestoJugador += ganancia;
            }
            else
            {
                mensajeResultado += $"\nLo sentimos, no ganaste tu apuesta por {_caballoApostadoPorJugador.Nombre}.";
            }

            ActualizarPresupuestoVisual();

            // Mostrar mensaje en el Label o MessageBox
            lblResultadoPartida.Text = mensajeResultado;
            lblResultadoPartida.Visible = true;
            MessageBox.Show(mensajeResultado, "Fin de la Partida", MessageBoxButtons.OK, MessageBoxIcon.Information);

            // Habilitar controles para una nueva partida
            // gbConfiguracion.Enabled = true;
            rbRapida.Enabled = true;
            rbEstandar.Enabled = true;
            rbExtensa.Enabled = true;
            cmbCaballoApuesta.Enabled = true;
            nudMontoApuesta.Enabled = true;
            btnIniciarPartida.Enabled = true;

            // Validar si el jugador aún tiene presupuesto para seguir jugando
            if (_presupuestoJugador <= 0)
            {
                MessageBox.Show("Te has quedado sin presupuesto. ¡Fin del juego!", "Bancarrota", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                // Podrías deshabilitar todo o cerrar la aplicación
                btnIniciarPartida.Enabled = false;
                nudMontoApuesta.Enabled = false;
            }
        }

        // Evento Load del Formulario (puedes hacer doble clic en el formulario en modo diseño para generarlo)
        private void FormPrincipal_Load(object sender, EventArgs e)
        {
            // Esto es para asegurar que el directorio "Cartas" exista.
            // Idealmente, las cartas se distribuyen con la aplicación.
            if (!Directory.Exists(_directorioCartas))
            {
                Directory.CreateDirectory(_directorioCartas);
                MessageBox.Show($"Asegúrate de colocar las imágenes de las cartas en la carpeta: \n{_directorioCartas}\n" +
                                "Los nombres deben ser como 'oros_1.jpg', 'espadas_10.jpg', etc.",
                                "Faltan Imágenes de Cartas", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
        private void InicializarMusica()
        {
            try
            {

                string rutaMusica2 = Path.Combine(Directory.GetCurrentDirectory(), "Wii.wav");
                if (File.Exists(rutaMusica2))
                {
                    _reproductorMusica = new SoundPlayer(rutaMusica2);
                    _reproductorMusica.Play(); // Reproducir
                }
                else
                {
                    Console.WriteLine("Archivo de música no encontrado.");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error al inicializar música: {ex.Message}");
            }
        }
        private void btnAyuda_Click(object sender, EventArgs e)
        {
            string tituloAyuda = "Ayuda - Carrera de Caballos";
            StringBuilder mensajeAyuda = new StringBuilder();

            mensajeAyuda.AppendLine("¡Bienvenido a la Carrera de Caballos con Cartas Españolas!");
            mensajeAyuda.AppendLine("----------------------------------------------------");
            mensajeAyuda.AppendLine("OBJETIVO DEL JUEGO:");
            mensajeAyuda.AppendLine("Ser el primero en llevar a tu caballo elegido (o cualquier caballo) a la meta de puntos según el modo de juego.");
            mensajeAyuda.AppendLine("Si apostaste por el caballo ganador, ¡recibirás un premio!");
            mensajeAyuda.AppendLine();

            mensajeAyuda.AppendLine("CÓMO JUGAR:");
            mensajeAyuda.AppendLine("1. CONFIGURACIÓN DE PARTIDA:");
            mensajeAyuda.AppendLine("   - Modo de Juego: Elige la duración de la carrera:");
            mensajeAyuda.AppendLine("     * Rápida: El primer caballo en alcanzar 5 puntos gana.");
            mensajeAyuda.AppendLine("     * Estándar: El primer caballo en alcanzar 8 puntos gana.");
            mensajeAyuda.AppendLine("     * Extensa: El primer caballo en alcanzar 10 puntos gana.");
            mensajeAyuda.AppendLine("   - Tu Presupuesto: Muestra el dinero que tienes disponible para apostar.");
            mensajeAyuda.AppendLine("   - Apostar por: Selecciona el caballo (por su palo: Oros, Copas, Espadas, Bastos) al que quieres apostar.");
            mensajeAyuda.AppendLine("   - Monto: Ingresa la cantidad de dinero que deseas apostar por ese caballo.");
            mensajeAyuda.AppendLine("   - Iniciar Partida: Haz clic aquí para comenzar la carrera con la configuración seleccionada. Tu apuesta se descontará de tu presupuesto.");
            mensajeAyuda.AppendLine();

            mensajeAyuda.AppendLine("2. DURANTE EL JUEGO:");
            mensajeAyuda.AppendLine("   - Ronda Actual: Indica en qué ronda de sacar cartas te encuentras.");
            mensajeAyuda.AppendLine("   - Carta Sacada: Muestra la última carta extraída del mazo.");
            mensajeAyuda.AppendLine("   - Sacar Carta: Haz clic en este botón para extraer una nueva carta del mazo.");
            mensajeAyuda.AppendLine("     El palo de la carta sacada determinará qué caballo avanza 1 punto en la pista.");
            mensajeAyuda.AppendLine("     (Ej: Si sale una carta de Oros, el Caballo de Oros avanza).");
            mensajeAyuda.AppendLine("   - Pistas y Puntos: Cada caballo tiene su pista. Verás marcadores visuales y un contador de puntos por cada avance.");
            mensajeAyuda.AppendLine();

            mensajeAyuda.AppendLine("3. FIN DE LA PARTIDA:");
            mensajeAyuda.AppendLine("   - La partida termina cuando un caballo alcanza la meta de puntos del modo de juego seleccionado.");
            mensajeAyuda.AppendLine("   - Se anunciará el caballo ganador.");
            mensajeAyuda.AppendLine("   - Si apostaste por el caballo ganador, tu presupuesto aumentará (generalmente, recibes el doble de lo apostado).");
            mensajeAyuda.AppendLine("   - Si te quedas sin presupuesto, el juego podría terminar para ti.");
            mensajeAyuda.AppendLine();

            mensajeAyuda.AppendLine("IMÁGENES DE CARTAS:");
            mensajeAyuda.AppendLine("Asegúrate de que la carpeta 'Cartas' con las imágenes (ej: 'oros_1.jpg', 'espadas_10.jpg') esté en el mismo directorio que el archivo ejecutable del juego.");
            mensajeAyuda.AppendLine("----------------------------------------------------");
            mensajeAyuda.AppendLine("¡Mucha suerte en las carreras!");

            MessageBox.Show(mensajeAyuda.ToString(), tituloAyuda, MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        private void button1_Click(object sender, EventArgs e)
        {
            _reproductorMusica?.Stop();
            FormMenuPrincipal formMenuPrincipal = new FormMenuPrincipal();
            this.Close();
            formMenuPrincipal.Show();
        }
    }
}
