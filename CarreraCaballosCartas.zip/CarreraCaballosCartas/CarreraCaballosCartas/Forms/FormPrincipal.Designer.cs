﻿namespace CarreraCaballosCartas
{
    partial class FormPrincipal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormPrincipal));
            gbConfiguracion = new GroupBox();
            button1 = new Button();
            btnIniciarPartida = new Button();
            nudMontoApuesta = new NumericUpDown();
            lblMontoApuesta = new Label();
            cmbCaballoApuesta = new ComboBox();
            lblApostarPor = new Label();
            lblPresupuestoValor = new Label();
            lblPresupuestoInfo = new Label();
            rbExtensa = new RadioButton();
            lblModo = new Label();
            rbEstandar = new RadioButton();
            rbRapida = new RadioButton();
            groupBox1 = new GroupBox();
            btnSacarCarta = new Button();
            pbCartaActual = new PictureBox();
            lblCartaActualInfo = new Label();
            lblRondaValor = new Label();
            lblRondaInfo = new Label();
            flowLayoutPanel1 = new FlowLayoutPanel();
            groupBox2 = new GroupBox();
            lblPuntosOrosValor = new Label();
            flpOrosPista = new FlowLayoutPanel();
            lblPuntosOrosInfo = new Label();
            pbCaballoOros = new PictureBox();
            lblInfoOros = new Label();
            groupBox3 = new GroupBox();
            lblPuntosCopasValor = new Label();
            flpCopasPista = new FlowLayoutPanel();
            lblPuntosCopasInfo = new Label();
            pbCaballoCopas = new PictureBox();
            lblInfoCopas = new Label();
            groupBox4 = new GroupBox();
            lblPuntosEspadasValor = new Label();
            flpEspadasPista = new FlowLayoutPanel();
            lblPuntosEspadasInfo = new Label();
            pbCaballoEspadas = new PictureBox();
            lblInfoEspadas = new Label();
            groupBox5 = new GroupBox();
            lblPuntosBastosValor = new Label();
            flpBastosPista = new FlowLayoutPanel();
            lblPuntosBastosInfo = new Label();
            pbCaballoBastos = new PictureBox();
            lblInfoBastos = new Label();
            lblResultadoPartida = new Label();
            btnAyuda = new Button();
            gbConfiguracion.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)nudMontoApuesta).BeginInit();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pbCartaActual).BeginInit();
            flowLayoutPanel1.SuspendLayout();
            groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pbCaballoOros).BeginInit();
            groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pbCaballoCopas).BeginInit();
            groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pbCaballoEspadas).BeginInit();
            groupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pbCaballoBastos).BeginInit();
            SuspendLayout();
            // 
            // gbConfiguracion
            // 
            gbConfiguracion.BackColor = Color.Transparent;
            gbConfiguracion.Controls.Add(button1);
            gbConfiguracion.Controls.Add(btnIniciarPartida);
            gbConfiguracion.Controls.Add(nudMontoApuesta);
            gbConfiguracion.Controls.Add(lblMontoApuesta);
            gbConfiguracion.Controls.Add(cmbCaballoApuesta);
            gbConfiguracion.Controls.Add(lblApostarPor);
            gbConfiguracion.Controls.Add(lblPresupuestoValor);
            gbConfiguracion.Controls.Add(lblPresupuestoInfo);
            gbConfiguracion.Controls.Add(rbExtensa);
            gbConfiguracion.Controls.Add(lblModo);
            gbConfiguracion.Controls.Add(rbEstandar);
            gbConfiguracion.Controls.Add(rbRapida);
            gbConfiguracion.Location = new Point(29, 28);
            gbConfiguracion.Name = "gbConfiguracion";
            gbConfiguracion.Size = new Size(881, 186);
            gbConfiguracion.TabIndex = 0;
            gbConfiguracion.TabStop = false;
            // 
            // button1
            // 
            button1.BackColor = Color.White;
            button1.Font = new Font("Jokerman", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button1.Location = new Point(57, 134);
            button1.Name = "button1";
            button1.Size = new Size(170, 41);
            button1.TabIndex = 15;
            button1.Text = "Salir del Juego";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // btnIniciarPartida
            // 
            btnIniciarPartida.BackColor = Color.White;
            btnIniciarPartida.Font = new Font("Jokerman", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnIniciarPartida.Location = new Point(291, 134);
            btnIniciarPartida.Name = "btnIniciarPartida";
            btnIniciarPartida.Size = new Size(170, 41);
            btnIniciarPartida.TabIndex = 14;
            btnIniciarPartida.Text = "Iniciar Partida";
            btnIniciarPartida.UseVisualStyleBackColor = false;
            btnIniciarPartida.Click += btnIniciarPartida_Click;
            // 
            // nudMontoApuesta
            // 
            nudMontoApuesta.BackColor = Color.White;
            nudMontoApuesta.Location = new Point(633, 134);
            nudMontoApuesta.Maximum = new decimal(new int[] { 1000, 0, 0, 0 });
            nudMontoApuesta.Minimum = new decimal(new int[] { 1, 0, 0, 0 });
            nudMontoApuesta.Name = "nudMontoApuesta";
            nudMontoApuesta.Size = new Size(160, 23);
            nudMontoApuesta.TabIndex = 13;
            nudMontoApuesta.Value = new decimal(new int[] { 1, 0, 0, 0 });
            // 
            // lblMontoApuesta
            // 
            lblMontoApuesta.AutoSize = true;
            lblMontoApuesta.BackColor = Color.White;
            lblMontoApuesta.Font = new Font("Jokerman", 10F);
            lblMontoApuesta.Location = new Point(545, 134);
            lblMontoApuesta.Name = "lblMontoApuesta";
            lblMontoApuesta.Size = new Size(59, 20);
            lblMontoApuesta.TabIndex = 12;
            lblMontoApuesta.Text = "Monto:";
            // 
            // cmbCaballoApuesta
            // 
            cmbCaballoApuesta.BackColor = Color.White;
            cmbCaballoApuesta.Font = new Font("Jokerman", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            cmbCaballoApuesta.FormattingEnabled = true;
            cmbCaballoApuesta.Location = new Point(651, 47);
            cmbCaballoApuesta.Name = "cmbCaballoApuesta";
            cmbCaballoApuesta.Size = new Size(185, 36);
            cmbCaballoApuesta.TabIndex = 11;
            // 
            // lblApostarPor
            // 
            lblApostarPor.AutoSize = true;
            lblApostarPor.BackColor = Color.White;
            lblApostarPor.Font = new Font("Jokerman", 10F);
            lblApostarPor.Location = new Point(545, 56);
            lblApostarPor.Name = "lblApostarPor";
            lblApostarPor.Size = new Size(98, 20);
            lblApostarPor.TabIndex = 10;
            lblApostarPor.Text = "Apostar por:";
            // 
            // lblPresupuestoValor
            // 
            lblPresupuestoValor.AutoSize = true;
            lblPresupuestoValor.BackColor = Color.White;
            lblPresupuestoValor.Font = new Font("Jokerman", 10F);
            lblPresupuestoValor.Location = new Point(683, 22);
            lblPresupuestoValor.Name = "lblPresupuestoValor";
            lblPresupuestoValor.Size = new Size(45, 20);
            lblPresupuestoValor.TabIndex = 9;
            lblPresupuestoValor.Text = "1000";
            // 
            // lblPresupuestoInfo
            // 
            lblPresupuestoInfo.AutoSize = true;
            lblPresupuestoInfo.BackColor = Color.White;
            lblPresupuestoInfo.Font = new Font("Jokerman", 10F);
            lblPresupuestoInfo.Location = new Point(545, 22);
            lblPresupuestoInfo.Name = "lblPresupuestoInfo";
            lblPresupuestoInfo.Size = new Size(122, 20);
            lblPresupuestoInfo.TabIndex = 8;
            lblPresupuestoInfo.Text = "Tu Presupuesto:";
            // 
            // rbExtensa
            // 
            rbExtensa.AutoSize = true;
            rbExtensa.BackColor = Color.White;
            rbExtensa.Location = new Point(168, 72);
            rbExtensa.Name = "rbExtensa";
            rbExtensa.Size = new Size(127, 19);
            rbExtensa.TabIndex = 7;
            rbExtensa.TabStop = true;
            rbExtensa.Text = "Extensa (10 puntos)";
            rbExtensa.UseVisualStyleBackColor = false;
            // 
            // lblModo
            // 
            lblModo.AutoSize = true;
            lblModo.BackColor = Color.White;
            lblModo.Font = new Font("Jokerman", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblModo.Location = new Point(6, 43);
            lblModo.Name = "lblModo";
            lblModo.Size = new Size(133, 24);
            lblModo.TabIndex = 4;
            lblModo.Text = "Modo de Juego";
            // 
            // rbEstandar
            // 
            rbEstandar.AutoSize = true;
            rbEstandar.BackColor = Color.White;
            rbEstandar.Location = new Point(168, 47);
            rbEstandar.Name = "rbEstandar";
            rbEstandar.Size = new Size(127, 19);
            rbEstandar.TabIndex = 6;
            rbEstandar.TabStop = true;
            rbEstandar.Text = "Estándar (8 puntos)";
            rbEstandar.UseVisualStyleBackColor = false;
            // 
            // rbRapida
            // 
            rbRapida.AutoSize = true;
            rbRapida.BackColor = Color.White;
            rbRapida.Location = new Point(168, 22);
            rbRapida.Name = "rbRapida";
            rbRapida.Size = new Size(118, 19);
            rbRapida.TabIndex = 5;
            rbRapida.TabStop = true;
            rbRapida.Text = "Rápida (5 puntos)";
            rbRapida.UseVisualStyleBackColor = false;
            // 
            // groupBox1
            // 
            groupBox1.BackColor = Color.Transparent;
            groupBox1.Controls.Add(btnSacarCarta);
            groupBox1.Controls.Add(pbCartaActual);
            groupBox1.Controls.Add(lblCartaActualInfo);
            groupBox1.Controls.Add(lblRondaValor);
            groupBox1.Controls.Add(lblRondaInfo);
            groupBox1.Location = new Point(29, 220);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(544, 137);
            groupBox1.TabIndex = 1;
            groupBox1.TabStop = false;
            groupBox1.Text = "Juego";
            // 
            // btnSacarCarta
            // 
            btnSacarCarta.Font = new Font("Jokerman", 11F);
            btnSacarCarta.Location = new Point(370, 42);
            btnSacarCarta.Name = "btnSacarCarta";
            btnSacarCarta.Size = new Size(117, 38);
            btnSacarCarta.TabIndex = 15;
            btnSacarCarta.Text = "Sacar Carta";
            btnSacarCarta.UseVisualStyleBackColor = true;
            btnSacarCarta.Click += btnSacarCarta_Click;
            // 
            // pbCartaActual
            // 
            pbCartaActual.BackColor = Color.Transparent;
            pbCartaActual.BorderStyle = BorderStyle.FixedSingle;
            pbCartaActual.Image = (Image)resources.GetObject("pbCartaActual.Image");
            pbCartaActual.Location = new Point(217, 15);
            pbCartaActual.Name = "pbCartaActual";
            pbCartaActual.Size = new Size(92, 116);
            pbCartaActual.SizeMode = PictureBoxSizeMode.StretchImage;
            pbCartaActual.TabIndex = 17;
            pbCartaActual.TabStop = false;
            // 
            // lblCartaActualInfo
            // 
            lblCartaActualInfo.AutoSize = true;
            lblCartaActualInfo.BackColor = Color.White;
            lblCartaActualInfo.Font = new Font("Jokerman", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblCartaActualInfo.Location = new Point(57, 49);
            lblCartaActualInfo.Name = "lblCartaActualInfo";
            lblCartaActualInfo.Size = new Size(118, 24);
            lblCartaActualInfo.TabIndex = 16;
            lblCartaActualInfo.Text = "Carta Sacada:";
            // 
            // lblRondaValor
            // 
            lblRondaValor.AutoSize = true;
            lblRondaValor.BackColor = Color.White;
            lblRondaValor.Font = new Font("Jokerman", 10F);
            lblRondaValor.Location = new Point(497, 103);
            lblRondaValor.Name = "lblRondaValor";
            lblRondaValor.Size = new Size(19, 20);
            lblRondaValor.TabIndex = 15;
            lblRondaValor.Text = "0";
            // 
            // lblRondaInfo
            // 
            lblRondaInfo.AutoSize = true;
            lblRondaInfo.BackColor = Color.White;
            lblRondaInfo.Font = new Font("Jokerman", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblRondaInfo.Location = new Point(370, 100);
            lblRondaInfo.Name = "lblRondaInfo";
            lblRondaInfo.Size = new Size(121, 24);
            lblRondaInfo.TabIndex = 15;
            lblRondaInfo.Text = "Ronda Actual:";
            // 
            // flowLayoutPanel1
            // 
            flowLayoutPanel1.BackColor = Color.Transparent;
            flowLayoutPanel1.Controls.Add(groupBox2);
            flowLayoutPanel1.Controls.Add(groupBox3);
            flowLayoutPanel1.Controls.Add(groupBox4);
            flowLayoutPanel1.Controls.Add(groupBox5);
            flowLayoutPanel1.Controls.Add(lblResultadoPartida);
            flowLayoutPanel1.Location = new Point(35, 363);
            flowLayoutPanel1.Name = "flowLayoutPanel1";
            flowLayoutPanel1.Size = new Size(1009, 437);
            flowLayoutPanel1.TabIndex = 2;
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(lblPuntosOrosValor);
            groupBox2.Controls.Add(flpOrosPista);
            groupBox2.Controls.Add(lblPuntosOrosInfo);
            groupBox2.Controls.Add(pbCaballoOros);
            groupBox2.Controls.Add(lblInfoOros);
            groupBox2.Location = new Point(3, 3);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(243, 404);
            groupBox2.TabIndex = 0;
            groupBox2.TabStop = false;
            // 
            // lblPuntosOrosValor
            // 
            lblPuntosOrosValor.AutoSize = true;
            lblPuntosOrosValor.BackColor = Color.White;
            lblPuntosOrosValor.Font = new Font("Jokerman", 10F);
            lblPuntosOrosValor.Location = new Point(129, 132);
            lblPuntosOrosValor.Name = "lblPuntosOrosValor";
            lblPuntosOrosValor.Size = new Size(19, 20);
            lblPuntosOrosValor.TabIndex = 20;
            lblPuntosOrosValor.Text = "0";
            // 
            // flpOrosPista
            // 
            flpOrosPista.BorderStyle = BorderStyle.FixedSingle;
            flpOrosPista.Location = new Point(6, 155);
            flpOrosPista.Name = "flpOrosPista";
            flpOrosPista.Size = new Size(230, 243);
            flpOrosPista.TabIndex = 1;
            // 
            // lblPuntosOrosInfo
            // 
            lblPuntosOrosInfo.AutoSize = true;
            lblPuntosOrosInfo.BackColor = Color.White;
            lblPuntosOrosInfo.Font = new Font("Jokerman", 10F);
            lblPuntosOrosInfo.Location = new Point(58, 132);
            lblPuntosOrosInfo.Name = "lblPuntosOrosInfo";
            lblPuntosOrosInfo.Size = new Size(62, 20);
            lblPuntosOrosInfo.TabIndex = 19;
            lblPuntosOrosInfo.Text = "Puntos:";
            // 
            // pbCaballoOros
            // 
            pbCaballoOros.BackColor = Color.White;
            pbCaballoOros.Image = (Image)resources.GetObject("pbCaballoOros.Image");
            pbCaballoOros.Location = new Point(74, 42);
            pbCaballoOros.Name = "pbCaballoOros";
            pbCaballoOros.Size = new Size(65, 78);
            pbCaballoOros.SizeMode = PictureBoxSizeMode.StretchImage;
            pbCaballoOros.TabIndex = 0;
            pbCaballoOros.TabStop = false;
            // 
            // lblInfoOros
            // 
            lblInfoOros.AutoSize = true;
            lblInfoOros.BackColor = Color.White;
            lblInfoOros.Font = new Font("Jokerman", 10F);
            lblInfoOros.Location = new Point(48, 19);
            lblInfoOros.Name = "lblInfoOros";
            lblInfoOros.Size = new Size(118, 20);
            lblInfoOros.TabIndex = 18;
            lblInfoOros.Text = "Caballo de Oros";
            // 
            // groupBox3
            // 
            groupBox3.Controls.Add(lblPuntosCopasValor);
            groupBox3.Controls.Add(flpCopasPista);
            groupBox3.Controls.Add(lblPuntosCopasInfo);
            groupBox3.Controls.Add(pbCaballoCopas);
            groupBox3.Controls.Add(lblInfoCopas);
            groupBox3.Location = new Point(252, 3);
            groupBox3.Name = "groupBox3";
            groupBox3.Size = new Size(239, 404);
            groupBox3.TabIndex = 21;
            groupBox3.TabStop = false;
            // 
            // lblPuntosCopasValor
            // 
            lblPuntosCopasValor.AutoSize = true;
            lblPuntosCopasValor.BackColor = Color.White;
            lblPuntosCopasValor.Font = new Font("Jokerman", 10F);
            lblPuntosCopasValor.Location = new Point(129, 132);
            lblPuntosCopasValor.Name = "lblPuntosCopasValor";
            lblPuntosCopasValor.Size = new Size(19, 20);
            lblPuntosCopasValor.TabIndex = 20;
            lblPuntosCopasValor.Text = "0";
            // 
            // flpCopasPista
            // 
            flpCopasPista.BorderStyle = BorderStyle.FixedSingle;
            flpCopasPista.Location = new Point(6, 155);
            flpCopasPista.Name = "flpCopasPista";
            flpCopasPista.Size = new Size(227, 243);
            flpCopasPista.TabIndex = 1;
            // 
            // lblPuntosCopasInfo
            // 
            lblPuntosCopasInfo.AutoSize = true;
            lblPuntosCopasInfo.BackColor = Color.White;
            lblPuntosCopasInfo.Font = new Font("Jokerman", 10F);
            lblPuntosCopasInfo.Location = new Point(58, 132);
            lblPuntosCopasInfo.Name = "lblPuntosCopasInfo";
            lblPuntosCopasInfo.Size = new Size(62, 20);
            lblPuntosCopasInfo.TabIndex = 19;
            lblPuntosCopasInfo.Text = "Puntos:";
            // 
            // pbCaballoCopas
            // 
            pbCaballoCopas.BackColor = Color.White;
            pbCaballoCopas.Image = (Image)resources.GetObject("pbCaballoCopas.Image");
            pbCaballoCopas.Location = new Point(74, 42);
            pbCaballoCopas.Name = "pbCaballoCopas";
            pbCaballoCopas.Size = new Size(65, 78);
            pbCaballoCopas.SizeMode = PictureBoxSizeMode.StretchImage;
            pbCaballoCopas.TabIndex = 0;
            pbCaballoCopas.TabStop = false;
            // 
            // lblInfoCopas
            // 
            lblInfoCopas.AutoSize = true;
            lblInfoCopas.BackColor = Color.White;
            lblInfoCopas.Font = new Font("Jokerman", 10F);
            lblInfoCopas.Location = new Point(48, 19);
            lblInfoCopas.Name = "lblInfoCopas";
            lblInfoCopas.Size = new Size(127, 20);
            lblInfoCopas.TabIndex = 18;
            lblInfoCopas.Text = "Caballo de Copas";
            // 
            // groupBox4
            // 
            groupBox4.Controls.Add(lblPuntosEspadasValor);
            groupBox4.Controls.Add(flpEspadasPista);
            groupBox4.Controls.Add(lblPuntosEspadasInfo);
            groupBox4.Controls.Add(pbCaballoEspadas);
            groupBox4.Controls.Add(lblInfoEspadas);
            groupBox4.Location = new Point(497, 3);
            groupBox4.Name = "groupBox4";
            groupBox4.Size = new Size(243, 404);
            groupBox4.TabIndex = 21;
            groupBox4.TabStop = false;
            // 
            // lblPuntosEspadasValor
            // 
            lblPuntosEspadasValor.AutoSize = true;
            lblPuntosEspadasValor.BackColor = Color.White;
            lblPuntosEspadasValor.Font = new Font("Jokerman", 10F);
            lblPuntosEspadasValor.Location = new Point(129, 132);
            lblPuntosEspadasValor.Name = "lblPuntosEspadasValor";
            lblPuntosEspadasValor.Size = new Size(19, 20);
            lblPuntosEspadasValor.TabIndex = 20;
            lblPuntosEspadasValor.Text = "0";
            // 
            // flpEspadasPista
            // 
            flpEspadasPista.BorderStyle = BorderStyle.FixedSingle;
            flpEspadasPista.Location = new Point(6, 155);
            flpEspadasPista.Name = "flpEspadasPista";
            flpEspadasPista.Size = new Size(219, 243);
            flpEspadasPista.TabIndex = 1;
            // 
            // lblPuntosEspadasInfo
            // 
            lblPuntosEspadasInfo.AutoSize = true;
            lblPuntosEspadasInfo.BackColor = Color.White;
            lblPuntosEspadasInfo.Font = new Font("Jokerman", 10F);
            lblPuntosEspadasInfo.Location = new Point(58, 132);
            lblPuntosEspadasInfo.Name = "lblPuntosEspadasInfo";
            lblPuntosEspadasInfo.Size = new Size(62, 20);
            lblPuntosEspadasInfo.TabIndex = 19;
            lblPuntosEspadasInfo.Text = "Puntos:";
            // 
            // pbCaballoEspadas
            // 
            pbCaballoEspadas.BackColor = Color.White;
            pbCaballoEspadas.Image = (Image)resources.GetObject("pbCaballoEspadas.Image");
            pbCaballoEspadas.Location = new Point(83, 42);
            pbCaballoEspadas.Name = "pbCaballoEspadas";
            pbCaballoEspadas.Size = new Size(65, 78);
            pbCaballoEspadas.SizeMode = PictureBoxSizeMode.StretchImage;
            pbCaballoEspadas.TabIndex = 0;
            pbCaballoEspadas.TabStop = false;
            // 
            // lblInfoEspadas
            // 
            lblInfoEspadas.AutoSize = true;
            lblInfoEspadas.BackColor = Color.White;
            lblInfoEspadas.Font = new Font("Jokerman", 10F);
            lblInfoEspadas.Location = new Point(48, 19);
            lblInfoEspadas.Name = "lblInfoEspadas";
            lblInfoEspadas.Size = new Size(139, 20);
            lblInfoEspadas.TabIndex = 18;
            lblInfoEspadas.Text = "Caballo de Espadas";
            // 
            // groupBox5
            // 
            groupBox5.Controls.Add(lblPuntosBastosValor);
            groupBox5.Controls.Add(flpBastosPista);
            groupBox5.Controls.Add(lblPuntosBastosInfo);
            groupBox5.Controls.Add(pbCaballoBastos);
            groupBox5.Controls.Add(lblInfoBastos);
            groupBox5.Location = new Point(746, 3);
            groupBox5.Name = "groupBox5";
            groupBox5.Size = new Size(223, 404);
            groupBox5.TabIndex = 22;
            groupBox5.TabStop = false;
            // 
            // lblPuntosBastosValor
            // 
            lblPuntosBastosValor.AutoSize = true;
            lblPuntosBastosValor.BackColor = Color.White;
            lblPuntosBastosValor.Font = new Font("Jokerman", 10F);
            lblPuntosBastosValor.Location = new Point(129, 132);
            lblPuntosBastosValor.Name = "lblPuntosBastosValor";
            lblPuntosBastosValor.Size = new Size(19, 20);
            lblPuntosBastosValor.TabIndex = 20;
            lblPuntosBastosValor.Text = "0";
            // 
            // flpBastosPista
            // 
            flpBastosPista.BorderStyle = BorderStyle.FixedSingle;
            flpBastosPista.Location = new Point(6, 155);
            flpBastosPista.Name = "flpBastosPista";
            flpBastosPista.Size = new Size(211, 243);
            flpBastosPista.TabIndex = 1;
            // 
            // lblPuntosBastosInfo
            // 
            lblPuntosBastosInfo.AutoSize = true;
            lblPuntosBastosInfo.BackColor = Color.White;
            lblPuntosBastosInfo.Font = new Font("Jokerman", 10F);
            lblPuntosBastosInfo.Location = new Point(58, 132);
            lblPuntosBastosInfo.Name = "lblPuntosBastosInfo";
            lblPuntosBastosInfo.Size = new Size(62, 20);
            lblPuntosBastosInfo.TabIndex = 19;
            lblPuntosBastosInfo.Text = "Puntos:";
            // 
            // pbCaballoBastos
            // 
            pbCaballoBastos.BackColor = Color.White;
            pbCaballoBastos.Image = (Image)resources.GetObject("pbCaballoBastos.Image");
            pbCaballoBastos.Location = new Point(74, 42);
            pbCaballoBastos.Name = "pbCaballoBastos";
            pbCaballoBastos.Size = new Size(65, 78);
            pbCaballoBastos.SizeMode = PictureBoxSizeMode.StretchImage;
            pbCaballoBastos.TabIndex = 0;
            pbCaballoBastos.TabStop = false;
            // 
            // lblInfoBastos
            // 
            lblInfoBastos.AutoSize = true;
            lblInfoBastos.BackColor = Color.White;
            lblInfoBastos.Font = new Font("Jokerman", 10F);
            lblInfoBastos.Location = new Point(48, 19);
            lblInfoBastos.Name = "lblInfoBastos";
            lblInfoBastos.Size = new Size(130, 20);
            lblInfoBastos.TabIndex = 18;
            lblInfoBastos.Text = "Caballo de Bastos";
            // 
            // lblResultadoPartida
            // 
            lblResultadoPartida.AutoSize = true;
            lblResultadoPartida.BackColor = Color.White;
            lblResultadoPartida.Font = new Font("Jokerman", 10F);
            lblResultadoPartida.Location = new Point(3, 410);
            lblResultadoPartida.Name = "lblResultadoPartida";
            lblResultadoPartida.Size = new Size(78, 20);
            lblResultadoPartida.TabIndex = 21;
            lblResultadoPartida.Text = "Resultado";
            // 
            // btnAyuda
            // 
            btnAyuda.Font = new Font("Jokerman", 11F);
            btnAyuda.ForeColor = Color.Red;
            btnAyuda.Location = new Point(643, 262);
            btnAyuda.Name = "btnAyuda";
            btnAyuda.Size = new Size(160, 65);
            btnAyuda.TabIndex = 18;
            btnAyuda.Text = "AYUDA";
            btnAyuda.UseVisualStyleBackColor = true;
            btnAyuda.Click += btnAyuda_Click;
            // 
            // FormPrincipal
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            ClientSize = new Size(1066, 805);
            Controls.Add(btnAyuda);
            Controls.Add(flowLayoutPanel1);
            Controls.Add(groupBox1);
            Controls.Add(gbConfiguracion);
            MaximizeBox = false;
            Name = "FormPrincipal";
            Text = "FormPrincipal";
            gbConfiguracion.ResumeLayout(false);
            gbConfiguracion.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)nudMontoApuesta).EndInit();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pbCartaActual).EndInit();
            flowLayoutPanel1.ResumeLayout(false);
            flowLayoutPanel1.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pbCaballoOros).EndInit();
            groupBox3.ResumeLayout(false);
            groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pbCaballoCopas).EndInit();
            groupBox4.ResumeLayout(false);
            groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pbCaballoEspadas).EndInit();
            groupBox5.ResumeLayout(false);
            groupBox5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pbCaballoBastos).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private GroupBox gbConfiguracion;
        private RadioButton rbExtensa;
        private Label lblModo;
        private RadioButton rbEstandar;
        private RadioButton rbRapida;
        private NumericUpDown nudMontoApuesta;
        private Label lblMontoApuesta;
        private ComboBox cmbCaballoApuesta;
        private Label lblApostarPor;
        private Label lblPresupuestoValor;
        private Label lblPresupuestoInfo;
        private Button btnIniciarPartida;
        private GroupBox groupBox1;
        private Label lblRondaValor;
        private Label lblRondaInfo;
        private Button btnSacarCarta;
        private PictureBox pbCartaActual;
        private Label lblCartaActualInfo;
        private FlowLayoutPanel flowLayoutPanel1;
        private GroupBox groupBox2;
        private Label lblPuntosOrosValor;
        private Label lblPuntosOrosInfo;
        private PictureBox pbCaballoOros;
        private Label lblInfoOros;
        private FlowLayoutPanel flpOrosPista;
        private GroupBox groupBox3;
        private Label lblPuntosCopasValor;
        private FlowLayoutPanel flpCopasPista;
        private Label lblPuntosCopasInfo;
        private PictureBox pbCaballoCopas;
        private Label lblInfoCopas;
        private GroupBox groupBox4;
        private Label lblPuntosEspadasValor;
        private FlowLayoutPanel flpEspadasPista;
        private Label lblPuntosEspadasInfo;
        private PictureBox pbCaballoEspadas;
        private Label lblInfoEspadas;
        private GroupBox groupBox5;
        private Label lblPuntosBastosValor;
        private FlowLayoutPanel flpBastosPista;
        private Label lblPuntosBastosInfo;
        private PictureBox pbCaballoBastos;
        private Label lblInfoBastos;
        private Label lblResultadoPartida;
        private Button button1;
        private Button btnAyuda;
    }
}