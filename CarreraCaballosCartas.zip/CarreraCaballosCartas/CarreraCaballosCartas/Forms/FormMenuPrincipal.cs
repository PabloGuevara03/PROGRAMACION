using System.Media;

namespace CarreraCaballosCartas
{
    public partial class FormMenuPrincipal : Form
    {
        private SoundPlayer _reproductorMusica;
        public FormMenuPrincipal()
        {
            InitializeComponent();
            InicializarMusica();
        }
        private void InicializarMusica()
        {
            try
            {

                string rutaMusica = Path.Combine(Directory.GetCurrentDirectory(), "SoundTrackPerron.wav");
                if (File.Exists(rutaMusica))
                {
                    _reproductorMusica = new SoundPlayer(rutaMusica);
                    _reproductorMusica.PlayLooping(); // Reproducir
                }
                else
                {
                    Console.WriteLine("Archivo de m�sica no encontrado.");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error al inicializar m�sica: {ex.Message}");
            }
        }
        private void pictureBox1_Click(object sender, EventArgs e)
        {
            _reproductorMusica?.Stop();
            EasterEgg easterEgg = new EasterEgg();
            this.Hide();
            easterEgg.Show();

        }

        private void btnSalir_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            _reproductorMusica?.Stop();
            FormPrincipal formPrincipal = new FormPrincipal();
            this.Hide();
            formPrincipal.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Que Regla un Co�o Chico, TODO AL ROJO");
            return;
        }
    }
}
